# DOMI BOT

Asistente personal web con estética HUD futurista: chat, tareas, notas,
memoria configurable, 12 herramientas y soporte de voz — todo funcionando
localmente en el navegador, sin backend obligatorio.

## Estructura del proyecto

```
domi-bot/
├── index.html              # Estructura de toda la app (dashboard, chat, etc.)
├── css/
│   ├── variables.css        # Paleta, tipografía, radios, tokens de diseño
│   ├── base.css              # Reset y estilos globales
│   ├── layout.css            # Sidebar, grillas, estructura de cada vista
│   ├── components.css        # Paneles, botones, chips, mensajes, modales
│   ├── animations.css        # Keyframes y microanimaciones
│   └── responsive.css        # Adaptación móvil / tablet / PC
├── js/
│   ├── config.js              # Configuración estática (sin claves secretas)
│   ├── storage.js             # Envoltorio sobre localStorage
│   ├── state.js                # Estado central de la app
│   ├── utils.js                # Helpers (fechas, ids, escape html, etc.)
│   ├── ui.js                    # Navegación, tema, toasts, confirmaciones
│   ├── dashboard.js             # Panel de inicio
│   ├── memory.js                # Memoria de Domi (CRUD + búsqueda)
│   ├── ai.js                     # Motor local + conector a backend opcional
│   ├── chat.js                   # Chat y conversaciones
│   ├── tasks.js                  # Sistema de tareas (To-Do)
│   ├── notes.js                  # Sistema de notas
│   ├── tools.js                  # 12 herramientas (calculadora, etc.)
│   ├── voice.js                  # Reconocimiento y síntesis de voz
│   ├── settings.js               # Configuración y personalización
│   └── app.js                    # Arranque de la aplicación
├── api/
│   ├── server.example.js         # Backend de ejemplo (Node/Express)
│   └── README.md                  # Cómo conectar una IA real
└── README.md
```

## Cómo ejecutar el proyecto

DOMI BOT es una app 100% estática (HTML/CSS/JS puro, sin build ni
dependencias). Alcanza con servir la carpeta con cualquier servidor
estático — abrirla como `file://` directo puede bloquear algunas APIs
del navegador (voz, fuentes), así que se recomienda un servidor local:

**Opción A — Python (ya viene instalado en la mayoría de los sistemas):**
```bash
cd domi-bot
python3 -m http.server 8080
```
Abrí `http://localhost:8080` en el navegador.

**Opción B — Node.js:**
```bash
cd domi-bot
npx serve .
```

**Opción C — VS Code:** extensión "Live Server", clic derecho en
`index.html` → "Open with Live Server".

**Desde el celular (Android):** subí la carpeta a cualquier hosting
estático (GitHub Pages, Netlify, Vercel) y abrí la URL desde Chrome. La
interfaz ya está optimizada para pantallas táctiles y teclado móvil.

## Conectar una IA real

Por defecto, Domi responde con un motor local de demostración. Para
conectarlo a un modelo de IA real, seguí la guía completa en
[`api/README.md`](api/README.md): consiste en levantar un backend propio
que guarde la clave de API de forma segura (nunca en el navegador) y
apuntar la app a esa URL desde **Configuración → Conexión de IA**.

## Qué revisar antes de usarlo

- **Errores obvios**: abrí la consola del navegador (F12) al cargar la
  app; no debería haber errores en rojo.
- **Botones**: cada módulo (chat, tareas, notas, herramientas, memoria)
  tiene sus acciones probadas manualmente: crear, editar, eliminar,
  copiar, regenerar, filtrar y buscar.
- **Diseño móvil**: probá con las herramientas de desarrollo en modo
  responsive (o desde un Android real) — el sidebar se oculta detrás de
  un botón de menú y el chat se adapta al teclado virtual.
- **Modo claro/oscuro**: el selector en la barra lateral cambia el tema
  al instante y se recuerda entre sesiones.
- **Persistencia**: notas y tareas se guardan en `localStorage`; si
  recargás la página, siguen ahí. Si borrás los datos del sitio en el
  navegador, se pierden (es información 100% local, no hay servidor).

## Privacidad y datos

Todo lo que guardás — tareas, notas, memoria, conversaciones y ajustes —
vive únicamente en el `localStorage` de tu navegador. Nada se envía a
ningún servidor a menos que actives explícitamente un backend de IA
propio en Configuración.
