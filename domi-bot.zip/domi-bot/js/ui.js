/**
 * ui.js — mecánica transversal de la interfaz.
 */
const UI = (() => {
  let audioCtx = null;

  function beep(freq = 520, dur = 0.045, vol = 0.05){
    if (!AppState.settings.sounds) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.value = vol;
      osc.connect(gain); gain.connect(audioCtx.destination);
      osc.start();
      gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
      osc.stop(audioCtx.currentTime + dur);
    } catch { /* audio no disponible, se ignora silenciosamente */ }
  }

  // ---------- Navegación entre vistas ----------
  function goToView(viewName){
    document.querySelectorAll('.view').forEach(v => v.classList.remove('is-active'));
    const target = document.getElementById(`view-${viewName}`);
    if (target) target.classList.add('is-active');

    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.classList.toggle('is-active', btn.dataset.view === viewName);
    });

    const titles = {
      dashboard: 'Inicio', chat: 'Chat', tasks: 'Tareas', notes: 'Notas',
      tools: 'Herramientas', memory: 'Memoria de Domi', settings: 'Configuración'
    };
    document.getElementById('view-title').textContent = titles[viewName] || viewName;
    closeSidebar();
    beep(500, 0.04, 0.03);
  }

  function openSidebar(){
    document.getElementById('sidebar').classList.add('is-open');
    document.getElementById('sidebar-scrim').classList.add('is-active');
  }
  function closeSidebar(){
    document.getElementById('sidebar').classList.remove('is-open');
    document.getElementById('sidebar-scrim').classList.remove('is-active');
  }

  // ---------- Tema ----------
  function applyTheme(){
    const { theme, accent, fontsize, animations } = AppState.settings;
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-accent', accent);
    document.documentElement.style.setProperty('--scale', (fontsize / 100).toFixed(2));
    document.body.classList.toggle('no-animations', !animations);

    const icon = document.getElementById('theme-icon');
    const label = document.getElementById('theme-label');
    if (icon && label) {
      icon.textContent = theme === 'dark' ? '🌙' : '☀️';
      label.textContent = theme === 'dark' ? 'Modo oscuro' : 'Modo claro';
    }
    document.querySelectorAll('.swatch').forEach(sw => {
      sw.classList.toggle('is-active', sw.dataset.accent === accent);
    });
  }

  function toggleTheme(){
    AppState.settings.theme = AppState.settings.theme === 'dark' ? 'light' : 'dark';
    AppState.persistSettings();
    applyTheme();
    beep(600, 0.05, 0.04);
  }

  // ---------- Toasts ----------
  function toast(message, type = 'info'){
    const stack = document.getElementById('toast-stack');
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    const icons = { success:'✓', error:'✕', info:'ℹ' };
    el.innerHTML = `<span>${icons[type] || 'ℹ'}</span><span>${Utils.escapeHtml(message)}</span>`;
    stack.appendChild(el);
    beep(type === 'error' ? 300 : 620, 0.05, 0.035);
    setTimeout(() => {
      el.style.transition = 'opacity .3s ease, transform .3s ease';
      el.style.opacity = '0';
      el.style.transform = 'translateX(20px)';
      setTimeout(() => el.remove(), 300);
    }, DOMI_CONFIG.TOAST_TTL);
  }

  // ---------- Confirmación ----------
  function confirmAction(message){
    return new Promise((resolve) => {
      const scrim = document.getElementById('confirm-scrim');
      document.getElementById('confirm-message').textContent = message;
      scrim.classList.add('is-active');

      const okBtn = document.getElementById('confirm-ok');
      const cancelBtn = document.getElementById('confirm-cancel');

      const cleanup = (result) => {
        scrim.classList.remove('is-active');
        okBtn.removeEventListener('click', onOk);
        cancelBtn.removeEventListener('click', onCancel);
        resolve(result);
      };
      const onOk = () => cleanup(true);
      const onCancel = () => cleanup(false);

      okBtn.addEventListener('click', onOk);
      cancelBtn.addEventListener('click', onCancel);
    });
  }

  // ---------- Reloj del dashboard ----------
  function startClock(){
    const timeEl = document.getElementById('dash-time');
    const dateEl = document.getElementById('dash-date');
    function tick(){
      const now = new Date();
      if (timeEl) timeEl.textContent = Utils.formatTime(now);
      if (dateEl) dateEl.textContent = Utils.formatDate(now);
    }
    tick();
    setInterval(tick, 1000);
  }

  function bindNav(){
    document.querySelectorAll('[data-view]').forEach(el => {
      el.addEventListener('click', () => goToView(el.dataset.view));
    });
    document.getElementById('sidebar-open').addEventListener('click', openSidebar);
    document.getElementById('sidebar-close').addEventListener('click', closeSidebar);
    document.getElementById('sidebar-scrim').addEventListener('click', closeSidebar);
    document.getElementById('theme-toggle').addEventListener('click', toggleTheme);
    document.getElementById('quick-chat-btn').addEventListener('click', () => goToView('chat'));

    // Atajos de teclado en PC
    document.addEventListener('keydown', (e) => {
      if (e.ctrlKey || e.metaKey) {
        const map = { '1':'dashboard','2':'chat','3':'tasks','4':'notes','5':'tools','6':'memory','7':'settings' };
        if (map[e.key]) { e.preventDefault(); goToView(map[e.key]); }
      }
      if (e.key === 'Escape') {
        document.getElementById('tool-modal-scrim')?.classList.remove('is-active');
        document.getElementById('tool-modal')?.classList.remove('is-active');
        document.getElementById('tool-modal').style.display = 'none';
        document.getElementById('tool-modal-scrim').style.display = 'none';
      }
    });
  }

  return { goToView, openSidebar, closeSidebar, applyTheme, toggleTheme, toast, confirmAction, startClock, bindNav, beep };
})();
