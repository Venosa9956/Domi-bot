/**
 * storage.js
 * Envoltorio simple y seguro sobre localStorage.
 * Todos los datos del usuario viven únicamente en su navegador.
 */
const Storage = (() => {
  const key = (k) => `${DOMI_CONFIG.STORAGE_PREFIX}${k}`;

  function get(k, fallback = null) {
    try {
      const raw = localStorage.getItem(key(k));
      if (raw === null) return fallback;
      return JSON.parse(raw);
    } catch (e) {
      console.warn('[Storage] error leyendo', k, e);
      return fallback;
    }
  }

  function set(k, value) {
    try {
      localStorage.setItem(key(k), JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn('[Storage] error guardando', k, e);
      return false;
    }
  }

  function remove(k) {
    localStorage.removeItem(key(k));
  }

  function allKeys() {
    return Object.keys(localStorage).filter(k => k.startsWith(DOMI_CONFIG.STORAGE_PREFIX));
  }

  function exportAll() {
    const data = {};
    allKeys().forEach(fullKey => {
      const shortKey = fullKey.replace(DOMI_CONFIG.STORAGE_PREFIX, '');
      try { data[shortKey] = JSON.parse(localStorage.getItem(fullKey)); }
      catch { /* ignore malformed entry */ }
    });
    return data;
  }

  function clearAll() {
    allKeys().forEach(k => localStorage.removeItem(k));
  }

  function isAvailable() {
    try {
      const testKey = key('__test__');
      localStorage.setItem(testKey, '1');
      localStorage.removeItem(testKey);
      return true;
    } catch {
      return false;
    }
  }

  return { get, set, remove, allKeys, exportAll, clearAll, isAvailable };
})();
