/**
 * utils.js — helpers puros, sin estado.
 */
const Utils = {
  uid(){
    return `${Date.now().toString(36)}${Math.random().toString(36).slice(2,8)}`;
  },

  escapeHtml(str = ''){
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  },

  debounce(fn, ms = 300){
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), ms);
    };
  },

  formatTime(date = new Date()){
    return date.toLocaleTimeString('es-AR', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
  },

  formatShortTime(date = new Date()){
    return date.toLocaleTimeString('es-AR', { hour:'2-digit', minute:'2-digit' });
  },

  formatDate(date = new Date()){
    return date.toLocaleDateString('es-AR', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
  },

  formatRelative(ts){
    const diff = Date.now() - ts;
    const min = Math.floor(diff / 60000);
    if (min < 1) return 'justo ahora';
    if (min < 60) return `hace ${min} min`;
    const hr = Math.floor(min / 60);
    if (hr < 24) return `hace ${hr} h`;
    const days = Math.floor(hr / 24);
    return `hace ${days} d`;
  },

  greetingByHour(){
    const h = new Date().getHours();
    if (h < 6) return 'Trasnochando, ¿eh?';
    if (h < 12) return 'Buen día';
    if (h < 19) return 'Buenas tardes';
    return 'Buenas noches';
  },

  clamp(n, min, max){ return Math.max(min, Math.min(max, n)); },

  download(filename, text){
    const blob = new Blob([text], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  },

  copyToClipboard(text){
    if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(text);
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); ta.remove();
    return Promise.resolve();
  }
};
