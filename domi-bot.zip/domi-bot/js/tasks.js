/**
 * tasks.js — To-Do con persistencia local.
 */
const Tasks = (() => {
  function add(title, priority, category, date){
    if (AppState.tasks.length >= DOMI_CONFIG.MAX_TASKS) {
      UI.toast('Llegaste al límite de tareas', 'error'); return;
    }
    AppState.tasks.unshift({
      id: Utils.uid(), title, priority, category: category || 'General',
      date: date || null, done: false, createdAt: Date.now()
    });
    AppState.persistTasks();
    AppState.logActivity(`Nueva tarea: "${title}"`);
  }

  function toggle(id){
    const t = AppState.tasks.find(t => t.id === id);
    if (!t) return;
    t.done = !t.done;
    AppState.persistTasks();
  }

  function remove(id){
    AppState.tasks = AppState.tasks.filter(t => t.id !== id);
    AppState.persistTasks();
  }

  function update(id, patch){
    const t = AppState.tasks.find(t => t.id === id);
    if (!t) return;
    Object.assign(t, patch);
    AppState.persistTasks();
  }

  function filtered(){
    if (AppState.taskFilter === 'pendientes') return AppState.tasks.filter(t => !t.done);
    if (AppState.taskFilter === 'completadas') return AppState.tasks.filter(t => t.done);
    return AppState.tasks;
  }

  function render(){
    const list = document.getElementById('task-list');
    const items = filtered();
    if (!items.length){
      list.innerHTML = `<li class="empty-state">No hay tareas ${AppState.taskFilter === 'todas' ? '' : AppState.taskFilter} por ahora.</li>`;
      return;
    }
    list.innerHTML = items.map(t => `
      <li class="task-item ${t.done ? 'is-done' : ''}" data-id="${t.id}">
        <button class="task-check" data-act="toggle">${t.done ? '✓' : ''}</button>
        <div class="task-body">
          <div class="task-title">${Utils.escapeHtml(t.title)}</div>
          <div class="task-meta">
            <span class="tag prio-${t.priority}">${t.priority}</span>
            <span class="tag">${Utils.escapeHtml(t.category)}</span>
            ${t.date ? `<span class="tag">📅 ${t.date}</span>` : ''}
          </div>
        </div>
        <div class="task-actions">
          <button class="icon-btn small danger" data-act="delete" title="Eliminar">🗑</button>
        </div>
      </li>
    `).join('');

    list.querySelectorAll('.task-item').forEach(el => {
      const id = el.dataset.id;
      el.querySelector('[data-act="toggle"]').addEventListener('click', () => {
        toggle(id); render(); Dashboard.render();
      });
      el.querySelector('[data-act="delete"]').addEventListener('click', async () => {
        const ok = await UI.confirmAction('¿Eliminar esta tarea?');
        if (!ok) return;
        remove(id); render(); Dashboard.render();
        UI.toast('Tarea eliminada', 'success');
      });
    });
  }

  function bind(){
    document.getElementById('task-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const title = document.getElementById('task-title').value.trim();
      const priority = document.getElementById('task-priority').value;
      const category = document.getElementById('task-category').value.trim();
      const date = document.getElementById('task-date').value;
      if (!title) return;
      add(title, priority, category, date);
      e.target.reset();
      document.getElementById('task-priority').value = 'media';
      render();
      Dashboard.render();
      UI.toast('Tarea agregada', 'success');
    });

    document.getElementById('task-filters').addEventListener('click', (e) => {
      const btn = e.target.closest('.chip');
      if (!btn) return;
      AppState.taskFilter = btn.dataset.filter;
      document.querySelectorAll('#task-filters .chip').forEach(c => c.classList.toggle('is-active', c === btn));
      render();
    });
  }

  return { add, toggle, remove, update, render, bind };
})();
