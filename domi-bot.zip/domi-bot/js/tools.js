/**
 * tools.js — 12 herramientas, cada una en su propio panel modal.
 */
const Tools = (() => {
  let timerInterval = null, timerRemaining = 0, timerRunning = false;
  let stopwatchInterval = null, stopwatchElapsed = 0, stopwatchRunning = false, laps = [];

  const TOOL_DEFS = [
    { id:'calculator', icon:'🧮', label:'Calculadora', desc:'Operaciones básicas' },
    { id:'converter', icon:'⇄', label:'Conversor de unidades', desc:'Longitud, peso, temp.' },
    { id:'password', icon:'🔐', label:'Generador de contraseñas', desc:'Seguras y a medida' },
    { id:'quicknote', icon:'📝', label:'Notas rápidas', desc:'Acceso directo a Notas' },
    { id:'quicktask', icon:'☑', label:'Lista de tareas', desc:'Acceso directo a Tareas' },
    { id:'timer', icon:'⏲', label:'Temporizador', desc:'Cuenta regresiva' },
    { id:'stopwatch', icon:'⏱', label:'Cronómetro', desc:'Con vueltas' },
    { id:'worldclock', icon:'🌐', label:'Reloj mundial', desc:'Varias zonas horarias' },
    { id:'codepad', icon:'⌨', label:'Bloc de código', desc:'Con resaltado simple' },
    { id:'ideas', icon:'💡', label:'Generador de ideas', desc:'Para cuando te trabás' },
    { id:'searchnotes', icon:'🔍', label:'Buscar en notas', desc:'Búsqueda rápida' },
    { id:'calendar', icon:'📅', label:'Calendario', desc:'Vista mensual básica' }
  ];

  function renderGrid(){
    const grid = document.getElementById('tools-grid');
    grid.innerHTML = TOOL_DEFS.map(t => `
      <button class="tool-card" data-tool="${t.id}">
        <span class="card-ico">${t.icon}</span>
        <span class="card-label">${t.label}</span>
        <span class="card-desc">${t.desc}</span>
      </button>
    `).join('');
    grid.querySelectorAll('.tool-card').forEach(btn => {
      btn.addEventListener('click', () => openTool(btn.dataset.tool));
    });
  }

  function openTool(id){
    const def = TOOL_DEFS.find(t => t.id === id);
    document.getElementById('tool-modal-title').textContent = def.label;
    document.getElementById('tool-modal-body').innerHTML = bodyFor(id);
    document.getElementById('tool-modal-scrim').style.display = 'block';
    document.getElementById('tool-modal').style.display = 'flex';
    document.getElementById('tool-modal').style.flexDirection = 'column';
    bindTool(id);
  }

  function closeTool(){
    stopTimerTick();
    document.getElementById('tool-modal-scrim').style.display = 'none';
    document.getElementById('tool-modal').style.display = 'none';
  }

  function bodyFor(id){
    switch (id) {
      case 'calculator': return `
        <input type="text" id="calc-display" class="tool-result" readonly value="0">
        <div class="tool-row" style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;width:100%;">
          ${['7','8','9','/','4','5','6','*','1','2','3','-','0','.','=','+','C'].map(k =>
            `<button class="btn-secondary" data-calc="${k}" style="padding:14px 0;">${k}</button>`).join('')}
        </div>`;

      case 'converter': return `
        <div class="field"><span>Tipo</span>
          <select id="conv-type">
            <option value="length">Longitud (m ⇄ km ⇄ mi ⇄ ft)</option>
            <option value="weight">Peso (kg ⇄ g ⇄ lb)</option>
            <option value="temp">Temperatura (°C ⇄ °F ⇄ K)</option>
          </select>
        </div>
        <div class="tool-row">
          <input type="number" id="conv-value" placeholder="Valor" style="flex:1;">
          <select id="conv-from" style="flex:1;"></select>
          <span>→</span>
          <select id="conv-to" style="flex:1;"></select>
        </div>
        <div class="tool-result" id="conv-result">—</div>`;

      case 'password': return `
        <div class="tool-result" id="pwd-output" style="font-size:1.1rem;">Generá una contraseña</div>
        <div class="field"><span>Longitud: <b id="pwd-len-label">16</b></span>
          <input type="range" id="pwd-length" min="6" max="48" value="16"></div>
        <div class="settings-grid">
          <label class="field toggle-field"><span>Mayúsculas</span><input type="checkbox" id="pwd-upper" checked></label>
          <label class="field toggle-field"><span>Minúsculas</span><input type="checkbox" id="pwd-lower" checked></label>
          <label class="field toggle-field"><span>Números</span><input type="checkbox" id="pwd-numbers" checked></label>
          <label class="field toggle-field"><span>Símbolos</span><input type="checkbox" id="pwd-symbols" checked></label>
        </div>
        <div class="tool-row">
          <button class="btn-primary" id="pwd-generate">Generar</button>
          <button class="btn-secondary" id="pwd-copy">Copiar</button>
        </div>`;

      case 'quicknote': return `
        <p>Abrí el módulo de Notas para crear y organizar tus notas completas.</p>
        <button class="btn-primary" id="go-notes">Ir a Notas</button>`;

      case 'quicktask': return `
        <p>Abrí el módulo de Tareas para gestionar tu lista completa.</p>
        <button class="btn-primary" id="go-tasks">Ir a Tareas</button>`;

      case 'timer': return `
        <div class="timer-display" id="timer-display">00:00</div>
        <div class="tool-row">
          <input type="number" id="timer-min" placeholder="Min" min="0" style="flex:1;">
          <input type="number" id="timer-sec" placeholder="Seg" min="0" max="59" style="flex:1;">
        </div>
        <div class="tool-row">
          <button class="btn-primary" id="timer-start">Iniciar</button>
          <button class="btn-secondary" id="timer-pause">Pausar</button>
          <button class="btn-secondary" id="timer-reset">Reiniciar</button>
        </div>`;

      case 'stopwatch': return `
        <div class="timer-display" id="sw-display">00:00.0</div>
        <div class="tool-row">
          <button class="btn-primary" id="sw-start">Iniciar</button>
          <button class="btn-secondary" id="sw-lap">Vuelta</button>
          <button class="btn-secondary" id="sw-reset">Reiniciar</button>
        </div>
        <ul id="sw-laps" style="display:flex;flex-direction:column;gap:6px;max-height:160px;overflow-y:auto;"></ul>`;

      case 'worldclock': return `<div id="world-clock-list" style="display:flex;flex-direction:column;gap:8px;"></div>`;

      case 'codepad': return `
        <textarea id="code-input" rows="10" style="font-family:var(--font-mono);font-size:0.85rem;" placeholder="Pegá o escribí tu código acá…"></textarea>
        <div class="tool-row">
          <button class="btn-secondary" id="code-copy">Copiar</button>
          <button class="btn-secondary" id="code-clear">Limpiar</button>
          <span id="code-count" style="color:var(--text-2);font-size:0.8rem;">0 caracteres</span>
        </div>`;

      case 'ideas': return `
        <div class="tool-result" id="idea-output" style="font-size:1rem;">Presioná el botón para inspirarte</div>
        <button class="btn-primary" id="idea-generate">Generar idea</button>`;

      case 'searchnotes': return `
        <input type="search" id="tool-note-search" placeholder="Buscar en tus notas…">
        <div id="tool-note-results" style="display:flex;flex-direction:column;gap:8px;max-height:280px;overflow-y:auto;"></div>`;

      case 'calendar': return `<div id="calendar-container"></div>`;

      default: return '<p>Herramienta no disponible.</p>';
    }
  }

  function bindTool(id){
    if (id === 'calculator') bindCalculator();
    if (id === 'converter') bindConverter();
    if (id === 'password') bindPassword();
    if (id === 'quicknote') document.getElementById('go-notes').addEventListener('click', () => { closeTool(); UI.goToView('notes'); });
    if (id === 'quicktask') document.getElementById('go-tasks').addEventListener('click', () => { closeTool(); UI.goToView('tasks'); });
    if (id === 'timer') bindTimer();
    if (id === 'stopwatch') bindStopwatch();
    if (id === 'worldclock') bindWorldClock();
    if (id === 'codepad') bindCodePad();
    if (id === 'ideas') bindIdeas();
    if (id === 'searchnotes') bindSearchNotes();
    if (id === 'calendar') bindCalendar();
  }

  // ---- Calculadora ----
  function bindCalculator(){
    const display = document.getElementById('calc-display');
    let expr = '';
    document.querySelectorAll('[data-calc]').forEach(btn => {
      btn.addEventListener('click', () => {
        const k = btn.dataset.calc;
        if (k === 'C') { expr = ''; display.value = '0'; return; }
        if (k === '=') {
          try {
            if (!/^[0-9+\-*/.\s]+$/.test(expr)) throw new Error('inválido');
            // eslint-disable-next-line no-new-func
            const result = Function(`"use strict"; return (${expr})`)();
            display.value = Number.isFinite(result) ? String(+result.toFixed(8)) : 'Error';
            expr = display.value;
          } catch { display.value = 'Error'; expr = ''; }
          return;
        }
        expr += k;
        display.value = expr;
      });
    });
  }

  // ---- Conversor ----
  const UNIT_SETS = {
    length: { m:1, km:1000, mi:1609.344, ft:0.3048, cm:0.01 },
    weight: { kg:1, g:0.001, lb:0.453592 }
  };
  function bindConverter(){
    const type = document.getElementById('conv-type');
    const from = document.getElementById('conv-from');
    const to = document.getElementById('conv-to');
    const value = document.getElementById('conv-value');
    const result = document.getElementById('conv-result');

    function fillUnits(){
      const t = type.value;
      const units = t === 'temp' ? ['C','F','K'] : Object.keys(UNIT_SETS[t]);
      from.innerHTML = units.map(u => `<option value="${u}">${u}</option>`).join('');
      to.innerHTML = units.map((u,i) => `<option value="${u}" ${i===1?'selected':''}>${u}</option>`).join('');
      compute();
    }

    function compute(){
      const t = type.value;
      const v = parseFloat(value.value);
      if (Number.isNaN(v)) { result.textContent = '—'; return; }
      let r;
      if (t === 'temp') {
        r = convertTemp(v, from.value, to.value);
      } else {
        const base = v * UNIT_SETS[t][from.value];
        r = base / UNIT_SETS[t][to.value];
      }
      result.textContent = `${v} ${from.value} = ${(+r.toFixed(6))} ${to.value}`;
    }

    function convertTemp(v, f, t){
      let c = v;
      if (f === 'F') c = (v - 32) * 5/9;
      if (f === 'K') c = v - 273.15;
      if (t === 'C') return c;
      if (t === 'F') return c * 9/5 + 32;
      if (t === 'K') return c + 273.15;
      return c;
    }

    type.addEventListener('change', fillUnits);
    [from, to, value].forEach(el => el.addEventListener('input', compute));
    fillUnits();
  }

  // ---- Contraseñas ----
  function bindPassword(){
    const lenInput = document.getElementById('pwd-length');
    const lenLabel = document.getElementById('pwd-len-label');
    const output = document.getElementById('pwd-output');
    lenInput.addEventListener('input', () => lenLabel.textContent = lenInput.value);

    function generate(){
      const len = +lenInput.value;
      const sets = [];
      if (document.getElementById('pwd-upper').checked) sets.push('ABCDEFGHJKLMNPQRSTUVWXYZ');
      if (document.getElementById('pwd-lower').checked) sets.push('abcdefghijkmnpqrstuvwxyz');
      if (document.getElementById('pwd-numbers').checked) sets.push('23456789');
      if (document.getElementById('pwd-symbols').checked) sets.push('!@#$%^&*()-_=+?');
      if (!sets.length) { output.textContent = 'Elegí al menos un tipo de carácter'; return; }
      const all = sets.join('');
      const arr = new Uint32Array(len);
      crypto.getRandomValues(arr);
      let pwd = '';
      for (let i = 0; i < len; i++) pwd += all[arr[i] % all.length];
      output.textContent = pwd;
    }
    document.getElementById('pwd-generate').addEventListener('click', generate);
    document.getElementById('pwd-copy').addEventListener('click', () => {
      const text = output.textContent;
      if (!text || text.includes('Generá')) return;
      Utils.copyToClipboard(text);
      UI.toast('Contraseña copiada', 'success');
    });
    generate();
  }

  // ---- Temporizador ----
  function stopTimerTick(){ clearInterval(timerInterval); clearInterval(stopwatchInterval); }
  function bindTimer(){
    const display = document.getElementById('timer-display');
    function paint(){
      const m = String(Math.floor(timerRemaining/60)).padStart(2,'0');
      const s = String(timerRemaining%60).padStart(2,'0');
      display.textContent = `${m}:${s}`;
    }
    paint();
    document.getElementById('timer-start').addEventListener('click', () => {
      if (timerRunning) return;
      if (timerRemaining <= 0) {
        const min = parseInt(document.getElementById('timer-min').value) || 0;
        const sec = parseInt(document.getElementById('timer-sec').value) || 0;
        timerRemaining = min*60 + sec;
      }
      if (timerRemaining <= 0) return UI.toast('Definí un tiempo primero', 'info');
      timerRunning = true;
      timerInterval = setInterval(() => {
        timerRemaining--;
        paint();
        if (timerRemaining <= 0) {
          clearInterval(timerInterval);
          timerRunning = false;
          UI.toast('¡Tiempo cumplido!', 'success');
          UI.beep(880, 0.2, 0.08);
        }
      }, 1000);
    });
    document.getElementById('timer-pause').addEventListener('click', () => {
      clearInterval(timerInterval); timerRunning = false;
    });
    document.getElementById('timer-reset').addEventListener('click', () => {
      clearInterval(timerInterval); timerRunning = false; timerRemaining = 0; paint();
    });
  }

  // ---- Cronómetro ----
  function bindStopwatch(){
    const display = document.getElementById('sw-display');
    const lapsList = document.getElementById('sw-laps');
    function paint(){
      const totalMs = stopwatchElapsed;
      const m = String(Math.floor(totalMs/60000)).padStart(2,'0');
      const s = String(Math.floor((totalMs%60000)/1000)).padStart(2,'0');
      const ds = String(Math.floor((totalMs%1000)/100));
      display.textContent = `${m}:${s}.${ds}`;
    }
    function paintLaps(){
      lapsList.innerHTML = laps.map((l,i) => `<li class="tool-list-item"><span>Vuelta ${i+1}</span><span>${l}</span></li>`).join('');
    }
    paint(); paintLaps();
    let start = 0;
    document.getElementById('sw-start').addEventListener('click', (e) => {
      if (stopwatchRunning) {
        clearInterval(stopwatchInterval); stopwatchRunning = false;
        e.target.textContent = 'Reanudar';
      } else {
        start = Date.now() - stopwatchElapsed;
        stopwatchInterval = setInterval(() => { stopwatchElapsed = Date.now() - start; paint(); }, 100);
        stopwatchRunning = true;
        e.target.textContent = 'Pausar';
      }
    });
    document.getElementById('sw-lap').addEventListener('click', () => {
      if (!stopwatchRunning) return;
      laps.unshift(display.textContent);
      paintLaps();
    });
    document.getElementById('sw-reset').addEventListener('click', () => {
      clearInterval(stopwatchInterval); stopwatchRunning = false; stopwatchElapsed = 0; laps = [];
      paint(); paintLaps();
      document.getElementById('sw-start').textContent = 'Iniciar';
    });
  }

  // ---- Reloj mundial ----
  function bindWorldClock(){
    const zones = [
      { label: 'Buenos Aires', tz: 'America/Argentina/Buenos_Aires' },
      { label: 'Ciudad de México', tz: 'America/Mexico_City' },
      { label: 'Madrid', tz: 'Europe/Madrid' },
      { label: 'Nueva York', tz: 'America/New_York' },
      { label: 'Tokio', tz: 'Asia/Tokyo' },
      { label: 'Londres', tz: 'Europe/London' }
    ];
    const list = document.getElementById('world-clock-list');
    function paint(){
      list.innerHTML = zones.map(z => {
        const time = new Date().toLocaleTimeString('es-AR', { timeZone: z.tz, hour:'2-digit', minute:'2-digit' });
        return `<div class="world-clock-item"><span>${z.label}</span><strong style="font-family:var(--font-mono);">${time}</strong></div>`;
      }).join('');
    }
    paint();
    const iv = setInterval(paint, 1000 * 20);
    document.getElementById('tool-modal-close').addEventListener('click', () => clearInterval(iv), { once:true });
  }

  // ---- Bloc de código ----
  function bindCodePad(){
    const input = document.getElementById('code-input');
    const count = document.getElementById('code-count');
    const saved = Storage.get('codepad-scratch', '');
    input.value = saved;
    count.textContent = `${saved.length} caracteres`;
    input.addEventListener('input', Utils.debounce(() => {
      Storage.set('codepad-scratch', input.value);
      count.textContent = `${input.value.length} caracteres`;
    }, 250));
    document.getElementById('code-copy').addEventListener('click', () => {
      Utils.copyToClipboard(input.value); UI.toast('Código copiado', 'success');
    });
    document.getElementById('code-clear').addEventListener('click', async () => {
      const ok = await UI.confirmAction('¿Vaciar el bloc de código?');
      if (!ok) return;
      input.value=''; Storage.set('codepad-scratch',''); count.textContent = '0 caracteres';
    });
  }

  // ---- Generador de ideas ----
  function bindIdeas(){
    const bank = [
      'Automatizá una tarea repetitiva que hacés todas las semanas.',
      'Creá una plantilla reutilizable para tus próximos proyectos.',
      'Escribí un resumen de lo que aprendiste este mes.',
      'Probá una herramienta nueva durante 20 minutos.',
      'Ordená una carpeta o proyecto que tenías pendiente.',
      'Anotá tres cosas que te gustaría mejorar y elegí una para hoy.',
      'Diseñá un mini-checklist para tu rutina matutina.',
      'Explorá un tema que te dé curiosidad, sin objetivo concreto.'
    ];
    document.getElementById('idea-generate').addEventListener('click', () => {
      document.getElementById('idea-output').textContent = bank[Math.floor(Math.random()*bank.length)];
    });
  }

  // ---- Buscador de notas ----
  function bindSearchNotes(){
    const input = document.getElementById('tool-note-search');
    const results = document.getElementById('tool-note-results');
    function paint(term){
      const t = term.toLowerCase().trim();
      const items = !t ? AppState.notes : AppState.notes.filter(n =>
        n.title.toLowerCase().includes(t) || n.body.toLowerCase().includes(t));
      results.innerHTML = items.length
        ? items.map(n => `<div class="tool-list-item"><span>${Utils.escapeHtml(n.title||'Sin título')}</span><span style="color:var(--text-2);font-size:0.75rem;">${Utils.formatRelative(n.updatedAt)}</span></div>`).join('')
        : `<p class="empty-state">Sin resultados</p>`;
    }
    paint('');
    input.addEventListener('input', Utils.debounce(() => paint(input.value), 150));
  }

  // ---- Calendario ----
  function bindCalendar(){
    const container = document.getElementById('calendar-container');
    const now = new Date();
    const year = now.getFullYear(), month = now.getMonth();
    const first = new Date(year, month, 1);
    const daysInMonth = new Date(year, month+1, 0).getDate();
    const startOffset = (first.getDay() + 6) % 7; // lunes=0
    const monthName = now.toLocaleDateString('es-AR', { month:'long', year:'numeric' });

    let cells = '';
    for (let i=0;i<startOffset;i++) cells += `<div class="cal-day is-empty">.</div>`;
    for (let d=1; d<=daysInMonth; d++) {
      const isToday = d === now.getDate();
      cells += `<div class="cal-day ${isToday?'is-today':''}">${d}</div>`;
    }
    container.innerHTML = `
      <p style="text-align:center;font-family:var(--font-display);font-weight:600;margin-bottom:10px;text-transform:capitalize;">${monthName}</p>
      <div class="calendar-grid">
        ${['L','M','X','J','V','S','D'].map(d=>`<div class="cal-head">${d}</div>`).join('')}
        ${cells}
      </div>`;
  }

  function bindModal(){
    document.getElementById('tool-modal-close').addEventListener('click', closeTool);
    document.getElementById('tool-modal-scrim').addEventListener('click', closeTool);
  }

  function init(){
    renderGrid();
    bindModal();
  }

  return { init };
})();
