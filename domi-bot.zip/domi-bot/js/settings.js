/**
 * settings.js — controla la sección de Configuración.
 */
const Settings = (() => {
  function loadIntoForm(){
    const s = AppState.settings;
    document.getElementById('set-username').value = s.username;
    document.getElementById('set-botname').value = s.botname;
    document.getElementById('set-theme').value = s.theme;
    document.getElementById('set-fontsize').value = s.fontsize;
    document.getElementById('set-animations').checked = s.animations;
    document.getElementById('set-sounds').checked = s.sounds;
    document.getElementById('set-personality').value = s.personality;
    document.getElementById('set-tts').checked = s.tts;
    document.getElementById('set-api-url').value = s.apiUrl;
    document.getElementById('set-use-backend').checked = s.useBackend;
    document.getElementById('brand-name').textContent = s.botname || DOMI_CONFIG.DEFAULT_BOT_NAME;
    UI.applyTheme();
  }

  function bind(){
    const s = AppState.settings;

    document.getElementById('set-username').addEventListener('input', (e) => {
      s.username = e.target.value.trim();
      AppState.persistSettings();
      Dashboard.render();
    });

    document.getElementById('set-botname').addEventListener('input', (e) => {
      s.botname = e.target.value.trim() || DOMI_CONFIG.DEFAULT_BOT_NAME;
      AppState.persistSettings();
      document.getElementById('brand-name').textContent = s.botname;
      Chat.renderMessages();
    });

    document.getElementById('set-theme').addEventListener('change', (e) => {
      s.theme = e.target.value; AppState.persistSettings(); UI.applyTheme();
    });

    document.getElementById('accent-swatches').addEventListener('click', (e) => {
      const sw = e.target.closest('.swatch');
      if (!sw) return;
      s.accent = sw.dataset.accent; AppState.persistSettings(); UI.applyTheme();
    });

    document.getElementById('set-fontsize').addEventListener('input', (e) => {
      s.fontsize = +e.target.value; AppState.persistSettings(); UI.applyTheme();
    });

    document.getElementById('set-animations').addEventListener('change', (e) => {
      s.animations = e.target.checked; AppState.persistSettings(); UI.applyTheme();
    });

    document.getElementById('set-sounds').addEventListener('change', (e) => {
      s.sounds = e.target.checked; AppState.persistSettings();
    });

    document.getElementById('set-personality').addEventListener('change', (e) => {
      s.personality = e.target.value; AppState.persistSettings();
    });

    document.getElementById('set-tts').addEventListener('change', (e) => {
      s.tts = e.target.checked; AppState.persistSettings();
    });

    document.getElementById('set-voice').addEventListener('change', (e) => {
      s.voiceURI = e.target.value; AppState.persistSettings();
    });

    document.getElementById('set-api-url').addEventListener('input', (e) => {
      s.apiUrl = e.target.value.trim(); AppState.persistSettings();
    });

    document.getElementById('set-use-backend').addEventListener('change', (e) => {
      s.useBackend = e.target.checked; AppState.persistSettings();
    });

    document.getElementById('set-api-test').addEventListener('click', async () => {
      const statusEl = document.getElementById('set-api-status');
      const url = document.getElementById('set-api-url').value.trim();
      if (!url) { statusEl.textContent = 'Ingresá una URL primero.'; statusEl.className = 'settings-status err'; return; }
      statusEl.textContent = 'Probando conexión…'; statusEl.className = 'settings-status';
      try {
        await AI.testConnection(url);
        statusEl.textContent = 'Conexión exitosa. El backend respondió correctamente.';
        statusEl.className = 'settings-status ok';
        UI.toast('Backend de IA conectado', 'success');
      } catch (err) {
        statusEl.textContent = `No se pudo conectar: ${err.message}`;
        statusEl.className = 'settings-status err';
        UI.toast('Falló la conexión con el backend', 'error');
      }
    });

    document.getElementById('set-export').addEventListener('click', () => {
      const data = Storage.exportAll();
      Utils.download(`domi-bot-datos-${Date.now()}.json`, JSON.stringify(data, null, 2));
      UI.toast('Datos exportados', 'success');
    });

    document.getElementById('set-reset').addEventListener('click', async () => {
      const ok = await UI.confirmAction('Esto borra TODOS tus datos (chats, tareas, notas, memoria y ajustes) de este navegador. ¿Continuar?');
      if (!ok) return;
      Storage.clearAll();
      UI.toast('Datos borrados. Recargando…', 'success');
      setTimeout(() => location.reload(), 900);
    });
  }

  return { loadIntoForm, bind };
})();
