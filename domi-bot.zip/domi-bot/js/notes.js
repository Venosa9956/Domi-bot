/**
 * notes.js — notas con guardado automático (debounce) y búsqueda.
 */
const Notes = (() => {
  let searchTerm = '';
  let saveTimer = null;

  function getActive(){
    return AppState.notes.find(n => n.id === AppState.activeNoteId) || null;
  }

  function create(){
    if (AppState.notes.length >= DOMI_CONFIG.MAX_NOTES) {
      UI.toast('Llegaste al límite de notas', 'error'); return null;
    }
    const note = { id: Utils.uid(), title: 'Nueva nota', category: '', body: '', createdAt: Date.now(), updatedAt: Date.now() };
    AppState.notes.unshift(note);
    AppState.activeNoteId = note.id;
    Storage.set('activeNoteId', note.id);
    AppState.persistNotes();
    AppState.logActivity('Creó una nota nueva');
    return note;
  }

  function remove(id){
    AppState.notes = AppState.notes.filter(n => n.id !== id);
    if (AppState.activeNoteId === id) {
      AppState.activeNoteId = AppState.notes[0]?.id || null;
      Storage.set('activeNoteId', AppState.activeNoteId);
    }
    AppState.persistNotes();
  }

  function filteredList(){
    const t = searchTerm.toLowerCase().trim();
    if (!t) return AppState.notes;
    return AppState.notes.filter(n =>
      n.title.toLowerCase().includes(t) || n.body.toLowerCase().includes(t) || n.category.toLowerCase().includes(t)
    );
  }

  function renderList(){
    const list = document.getElementById('notes-list');
    const items = filteredList();
    if (!items.length){
      list.innerHTML = `<li class="empty-state">${searchTerm ? 'Sin resultados.' : 'Sin notas todavía. Creá la primera.'}</li>`;
      return;
    }
    list.innerHTML = items.map(n => `
      <li class="note-item ${n.id === AppState.activeNoteId ? 'is-active' : ''}" data-id="${n.id}">
        <strong>${Utils.escapeHtml(n.title || 'Sin título')}</strong>
        <small>${n.category ? Utils.escapeHtml(n.category) + ' · ' : ''}${Utils.formatRelative(n.updatedAt)}</small>
      </li>
    `).join('');
    list.querySelectorAll('.note-item').forEach(el => {
      el.addEventListener('click', () => {
        AppState.activeNoteId = el.dataset.id;
        Storage.set('activeNoteId', AppState.activeNoteId);
        renderList();
        renderEditor();
      });
    });
  }

  function renderEditor(){
    const note = getActive();
    const titleInput = document.getElementById('note-title');
    const catInput = document.getElementById('note-category');
    const bodyInput = document.getElementById('note-body');
    const meta = document.getElementById('note-meta');

    if (!note) {
      titleInput.value = ''; catInput.value = ''; bodyInput.value = '';
      titleInput.disabled = catInput.disabled = bodyInput.disabled = true;
      meta.textContent = 'Creá o seleccioná una nota para editar';
      return;
    }
    titleInput.disabled = catInput.disabled = bodyInput.disabled = false;
    titleInput.value = note.title;
    catInput.value = note.category;
    bodyInput.value = note.body;
    meta.textContent = `Editado ${Utils.formatRelative(note.updatedAt)}`;
  }

  function scheduleSave(){
    clearTimeout(saveTimer);
    document.getElementById('note-meta').textContent = 'Guardando…';
    saveTimer = setTimeout(() => {
      const note = getActive();
      if (!note) return;
      note.title = document.getElementById('note-title').value.trim() || 'Sin título';
      note.category = document.getElementById('note-category').value.trim();
      note.body = document.getElementById('note-body').value;
      note.updatedAt = Date.now();
      AppState.persistNotes();
      document.getElementById('note-meta').textContent = `Guardado ${Utils.formatRelative(note.updatedAt)}`;
      renderList();
      Dashboard.render();
    }, 500);
  }

  function bind(){
    document.getElementById('note-new-btn').addEventListener('click', () => {
      create(); renderList(); renderEditor();
      document.getElementById('note-title').focus();
    });

    ['note-title', 'note-category', 'note-body'].forEach(id => {
      document.getElementById(id).addEventListener('input', scheduleSave);
    });

    document.getElementById('note-delete-btn').addEventListener('click', async () => {
      const note = getActive();
      if (!note) return;
      const ok = await UI.confirmAction('¿Eliminar esta nota definitivamente?');
      if (!ok) return;
      remove(note.id);
      renderList(); renderEditor(); Dashboard.render();
      UI.toast('Nota eliminada', 'success');
    });

    document.getElementById('note-search').addEventListener('input', Utils.debounce((e) => {
      searchTerm = e.target.value;
      renderList();
    }, 150));
  }

  function init(){
    renderList();
    renderEditor();
  }

  return { bind, init, renderList, renderEditor, create };
})();
