/**
 * voice.js — entrada por voz (Web Speech API) y lectura de respuestas (TTS).
 * Si el navegador no soporta alguna API, se avisa con un toast claro
 * en vez de romper la aplicación.
 */
const Voice = (() => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognizer = null;
  let listening = false;

  function supportsSTT(){ return !!SpeechRecognition; }
  function supportsTTS(){ return 'speechSynthesis' in window; }

  function listen(onResult){
    const micBtn = document.getElementById('mic-btn');
    if (!supportsSTT()) {
      UI.toast('Tu navegador no soporta reconocimiento de voz', 'error');
      return;
    }
    if (listening) { recognizer?.stop(); return; }

    recognizer = new SpeechRecognition();
    recognizer.lang = 'es-AR';
    recognizer.interimResults = false;
    recognizer.maxAlternatives = 1;

    recognizer.onstart = () => { listening = true; micBtn?.classList.add('is-listening'); };
    recognizer.onerror = (e) => {
      listening = false; micBtn?.classList.remove('is-listening');
      UI.toast('No se pudo captar el audio. Probá de nuevo.', 'error');
      console.warn('[Voice] error de reconocimiento', e.error);
    };
    recognizer.onend = () => { listening = false; micBtn?.classList.remove('is-listening'); };
    recognizer.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      onResult(transcript);
    };
    try { recognizer.start(); }
    catch { UI.toast('No se pudo iniciar el micrófono', 'error'); }
  }

  function speak(text){
    if (!supportsTTS()) {
      UI.toast('Tu navegador no soporta lectura por voz', 'error');
      return;
    }
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'es-AR';
    const voiceURI = AppState.settings.voiceURI;
    if (voiceURI) {
      const v = window.speechSynthesis.getVoices().find(v => v.voiceURI === voiceURI);
      if (v) utter.voice = v;
    }
    window.speechSynthesis.speak(utter);
  }

  function populateVoiceOptions(){
    if (!supportsTTS()) return;
    const select = document.getElementById('set-voice');
    function fill(){
      const voices = window.speechSynthesis.getVoices().filter(v => v.lang.startsWith('es') || true);
      select.innerHTML = '<option value="">Predeterminada del sistema</option>' +
        voices.map(v => `<option value="${v.voiceURI}">${v.name} (${v.lang})</option>`).join('');
      select.value = AppState.settings.voiceURI || '';
    }
    fill();
    window.speechSynthesis.onvoiceschanged = fill;
  }

  function checkSupport(){
    if (!supportsSTT()) document.getElementById('mic-btn')?.setAttribute('title', 'Voz no soportada en este navegador');
    if (!supportsTTS()) document.getElementById('set-tts')?.setAttribute('disabled', 'true');
  }

  return { listen, speak, populateVoiceOptions, checkSupport, supportsSTT, supportsTTS };
})();
