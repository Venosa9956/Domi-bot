/**
 * ai.js
 * Capa que separa la interfaz de chat del motor de respuestas.
 *
 * - Por defecto usa un motor LOCAL de demostración (reglas + variación),
 *   para que la app funcione de punta a punta sin backend.
 * - Si el usuario activa "Usar backend de IA" en Configuración y define
 *   una URL, las preguntas se envían a ESE backend (POST JSON) en vez
 *   de resolverse localmente. El backend es quien debe guardar la
 *   clave de la API de IA (ver /api/README.md) — nunca el navegador.
 */
const AI = (() => {

  async function reply({ message, personality, history }) {
    const { useBackend, apiUrl } = AppState.settings;

    if (useBackend && apiUrl) {
      try {
        return await callBackend({ message, personality, history, apiUrl });
      } catch (err) {
        console.warn('[AI] Falló el backend, uso el motor local como respaldo', err);
        UI.toast('No se pudo contactar al backend de IA, usando motor local', 'error');
        return localEngine({ message, personality, history });
      }
    }
    return localEngine({ message, personality, history });
  }

  async function callBackend({ message, personality, history, apiUrl }) {
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message,
        personality,
        history: history.slice(-10).map(m => ({ role: m.role, content: m.content }))
      })
    });
    if (!res.ok) throw new Error(`Backend respondió ${res.status}`);
    const data = await res.json();
    if (!data || typeof data.reply !== 'string') throw new Error('Formato de respuesta inválido');
    return data.reply;
  }

  async function testConnection(apiUrl) {
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: 'ping', personality: 'normal', history: [] })
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (typeof data.reply !== 'string') throw new Error('El backend no devolvió { reply: string }');
    return true;
  }

  // ---------------- Motor local de demostración ----------------
  function localEngine({ message, personality }) {
    const text = message.trim();
    const lower = text.toLowerCase();

    const botName = AppState.settings.botname || DOMI_CONFIG.DEFAULT_BOT_NAME;
    const userName = AppState.settings.username;

    let body = null;

    if (/^(hola|buenas|hey|qué tal|que tal)\b/.test(lower)) {
      body = userName ? `¡Hola, ${userName}! ¿En qué te ayudo?` : '¡Hola! ¿En qué te ayudo?';
    } else if (/hora es|qué hora/.test(lower)) {
      body = `Son las ${Utils.formatTime(new Date())}.`;
    } else if (/fecha|qué día es|que dia es/.test(lower)) {
      body = `Hoy es ${Utils.formatDate(new Date())}.`;
    } else if (/quién sos|quien sos|qué sos|que sos/.test(lower)) {
      body = `Soy ${botName}, tu asistente personal. Puedo charlar, ayudarte con tareas, notas, recordar cosas que me pidas y usar las herramientas del panel.`;
    } else if (/gracias/.test(lower)) {
      body = 'Cuando quieras. Para eso estoy.';
    } else if (/tarea|pendiente/.test(lower)) {
      const pending = AppState.tasks.filter(t => !t.done).length;
      body = pending
        ? `Tenés ${pending} tarea${pending === 1 ? '' : 's'} pendiente${pending === 1 ? '' : 's'}. Las podés ver en la sección Tareas.`
        : 'No tenés tareas pendientes por ahora. ¡Buen momento para sumar una nueva si querés!';
    } else if (/record[aá]/.test(lower)) {
      body = 'Si querés que recuerde algo de forma permanente, guardalo en la sección "Memoria de Domi" — ahí vos decidís qué se guarda.';
    } else if (/chiste|joke/.test(lower)) {
      body = pick([
        '¿Por qué el programador se quedó sin batería? Porque dejó todos sus procesos en segundo plano.',
        'Un bit le dice al otro: "¿vamos a tomar algo?" y el otro responde: "dale, uno o cero".',
        'Mi función favorita es la que nunca falla: try, catch y seguir adelante.'
      ]);
    } else if (/\d+\s*[\+\-\*\/]\s*\d+/.test(lower)) {
      const evalResult = safeMathEval(lower);
      body = evalResult !== null
        ? `El resultado es ${evalResult}. (Tip: también tenés una calculadora completa en Herramientas.)`
        : 'Esa cuenta no la pude resolver, pero probá la calculadora en Herramientas.';
    } else if (lower.length < 3) {
      body = '¿Podés contarme un poco más?';
    }

    if (!body) {
      body = pick([
        `Entiendo: "${text}". Contame un poco más para ayudarte mejor.`,
        'Sigo pensando en eso — mientras tanto, ¿ya revisaste tus tareas o herramientas?',
        'Tomo nota de lo que decís. ¿Querés que lo guarde en la memoria?',
        'Interesante. ¿Hay algo puntual en lo que te pueda ayudar ahora mismo?'
      ]);
    }

    return applyPersonality(body, personality, text);
  }

  function applyPersonality(body, personality, original){
    switch (personality) {
      case 'estudiante':
        return `${body}\n\nTe lo explico simple: pensalo paso a paso, como si fuera un mini-tutorial. Si algo no queda claro, preguntame de nuevo con otras palabras.`;
      case 'tecnico':
        return `${body}\n\n[detalle] entrada procesada: ${original.length} caracteres · modo local activo.`;
      case 'creativo':
        return `${body} ✨ (y si querés, le podemos dar una vuelta más original a la idea)`;
      case 'conciso':
        return body.split('\n')[0].split('. ')[0] + (body.includes('.') ? '.' : '');
      default:
        return body;
    }
  }

  function safeMathEval(str){
    const match = str.match(/(-?\d+(\.\d+)?)\s*([\+\-\*\/])\s*(-?\d+(\.\d+)?)/);
    if (!match) return null;
    const a = parseFloat(match[1]), op = match[3], b = parseFloat(match[4]);
    if (Number.isNaN(a) || Number.isNaN(b)) return null;
    switch (op) {
      case '+': return a + b;
      case '-': return a - b;
      case '*': return a * b;
      case '/': return b !== 0 ? +(a / b).toFixed(4) : null;
      default: return null;
    }
  }

  function pick(arr){ return arr[Math.floor(Math.random() * arr.length)]; }

  return { reply, testConnection };
})();
