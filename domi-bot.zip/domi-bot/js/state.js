/**
 * state.js
 * Estado central de la aplicación. Cada módulo lee/escribe acá y
 * persiste a través de Storage. No es un framework reactivo real:
 * cada módulo se re-renderiza a sí mismo cuando cambia algo suyo.
 */
const AppState = {
  settings: Storage.get('settings', {
    username: '',
    botname: DOMI_CONFIG.DEFAULT_BOT_NAME,
    theme: 'dark',
    accent: 'teal',
    fontsize: 100,
    animations: true,
    sounds: true,
    personality: 'normal',
    tts: false,
    voiceURI: '',
    apiUrl: '',
    useBackend: false
  }),

  conversations: Storage.get('conversations', []), // [{id,title,messages:[],createdAt,updatedAt,personality}]
  activeConvoId: Storage.get('activeConvoId', null),

  tasks: Storage.get('tasks', []), // [{id,title,priority,category,date,done,createdAt}]
  taskFilter: 'pendientes',

  notes: Storage.get('notes', []), // [{id,title,category,body,createdAt,updatedAt}]
  activeNoteId: Storage.get('activeNoteId', null),

  memories: Storage.get('memories', []), // [{id,title,category,content,createdAt}]

  activity: Storage.get('activity', []), // [{id,text,ts}]

  persistSettings(){ Storage.set('settings', this.settings); },
  persistConversations(){ Storage.set('conversations', this.conversations); },
  persistTasks(){ Storage.set('tasks', this.tasks); },
  persistNotes(){ Storage.set('notes', this.notes); },
  persistMemories(){ Storage.set('memories', this.memories); },
  persistActivity(){ Storage.set('activity', this.activity); },

  logActivity(text){
    this.activity.unshift({ id: Utils.uid(), text, ts: Date.now() });
    this.activity = this.activity.slice(0, 30);
    this.persistActivity();
  }
};
