/**
 * chat.js — interfaz de chat con historial de conversaciones.
 */
const Chat = (() => {
  let isThinking = false;

  function getActiveConvo(){
    return AppState.conversations.find(c => c.id === AppState.activeConvoId) || null;
  }

  function createConvo(){
    const convo = {
      id: Utils.uid(),
      title: 'Nueva conversación',
      messages: [],
      personality: AppState.settings.personality,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    AppState.conversations.unshift(convo);
    AppState.activeConvoId = convo.id;
    Storage.set('activeConvoId', convo.id);
    AppState.persistConversations();
    return convo;
  }

  function ensureConvo(){
    return getActiveConvo() || createConvo();
  }

  function deleteConvo(id){
    AppState.conversations = AppState.conversations.filter(c => c.id !== id);
    if (AppState.activeConvoId === id) {
      AppState.activeConvoId = AppState.conversations[0]?.id || null;
      Storage.set('activeConvoId', AppState.activeConvoId);
    }
    AppState.persistConversations();
  }

  function renderConvoList(){
    const list = document.getElementById('convo-list');
    if (!AppState.conversations.length){
      list.innerHTML = `<li class="empty-state">Sin conversaciones aún.</li>`;
      return;
    }
    list.innerHTML = AppState.conversations.map(c => `
      <li class="convo-item ${c.id === AppState.activeConvoId ? 'is-active' : ''}" data-id="${c.id}">
        <strong>${Utils.escapeHtml(c.title)}</strong>
        <small>${c.messages.length} mensaje${c.messages.length === 1 ? '' : 's'} · ${Utils.formatRelative(c.updatedAt)}</small>
      </li>
    `).join('');
    list.querySelectorAll('.convo-item').forEach(el => {
      el.addEventListener('click', () => {
        AppState.activeConvoId = el.dataset.id;
        Storage.set('activeConvoId', AppState.activeConvoId);
        const convo = getActiveConvo();
        if (convo) document.getElementById('personality-picker').value = convo.personality || 'normal';
        renderConvoList();
        renderMessages();
      });
    });
  }

  function renderMessages(){
    const box = document.getElementById('chat-messages');
    const convo = getActiveConvo();
    if (!convo || !convo.messages.length){
      box.innerHTML = `<div class="empty-state chat-empty">
        <span class="empty-ico">◎</span>
        <p>Empezá a escribirle a ${Utils.escapeHtml(AppState.settings.botname || DOMI_CONFIG.DEFAULT_BOT_NAME)}.</p>
      </div>`;
      return;
    }
    box.innerHTML = convo.messages.map(m => renderMessage(m)).join('');
    bindMessageActions();
    box.scrollTop = box.scrollHeight;
  }

  function renderMessage(m){
    const botName = AppState.settings.botname || DOMI_CONFIG.DEFAULT_BOT_NAME;
    const isUser = m.role === 'user';
    return `
      <div class="msg ${isUser ? 'user' : 'bot'}" data-id="${m.id}">
        <div class="msg-avatar">${isUser ? (AppState.settings.username?.[0]?.toUpperCase() || 'T') : botName[0].toUpperCase()}</div>
        <div>
          <div class="msg-bubble">${Utils.escapeHtml(m.content)}</div>
          <div class="msg-meta">
            <span class="msg-time">${Utils.formatShortTime(new Date(m.ts))}</span>
            <span class="msg-actions">
              <button data-act="copy" title="Copiar">Copiar</button>
              ${!isUser ? '<button data-act="regen" title="Regenerar">Regenerar</button>' : ''}
            </span>
          </div>
        </div>
      </div>
    `;
  }

  function bindMessageActions(){
    document.querySelectorAll('#chat-messages .msg').forEach(el => {
      const id = el.dataset.id;
      el.querySelector('[data-act="copy"]')?.addEventListener('click', () => {
        const convo = getActiveConvo();
        const msg = convo?.messages.find(m => m.id === id);
        if (msg) { Utils.copyToClipboard(msg.content); UI.toast('Respuesta copiada', 'success'); }
      });
      el.querySelector('[data-act="regen"]')?.addEventListener('click', () => regenerate(id));
    });
  }

  function showThinking(){
    isThinking = true;
    const box = document.getElementById('chat-messages');
    const el = document.createElement('div');
    el.className = 'msg bot';
    el.id = 'thinking-indicator';
    const botName = AppState.settings.botname || DOMI_CONFIG.DEFAULT_BOT_NAME;
    el.innerHTML = `
      <div class="msg-avatar">${botName[0].toUpperCase()}</div>
      <div class="msg-bubble"><div class="thinking-dots"><span></span><span></span><span></span></div></div>
    `;
    box.appendChild(el);
    box.scrollTop = box.scrollHeight;
  }
  function hideThinking(){
    isThinking = false;
    document.getElementById('thinking-indicator')?.remove();
  }

  async function sendMessage(){
    const input = document.getElementById('chat-input');
    const text = input.value.trim();
    if (!text || isThinking) return;

    const convo = ensureConvo();
    if (convo.title === 'Nueva conversación') {
      convo.title = text.slice(0, 36) + (text.length > 36 ? '…' : '');
    }
    convo.messages.push({ id: Utils.uid(), role: 'user', content: text, ts: Date.now() });
    convo.updatedAt = Date.now();
    AppState.persistConversations();
    input.value = '';
    autoGrow(input);
    renderConvoList();
    renderMessages();

    showThinking();
    const personality = document.getElementById('personality-picker').value;
    convo.personality = personality;

    const reply = await AI.reply({ message: text, personality, history: convo.messages });
    hideThinking();

    convo.messages.push({ id: Utils.uid(), role: 'bot', content: reply, ts: Date.now() });
    convo.updatedAt = Date.now();
    AppState.persistConversations();
    renderConvoList();
    renderMessages();
    AppState.logActivity('Nueva respuesta de Domi en el chat');
    Dashboard.render();

    if (AppState.settings.tts) Voice.speak(reply);
  }

  async function regenerate(messageId){
    const convo = getActiveConvo();
    if (!convo) return;
    const idx = convo.messages.findIndex(m => m.id === messageId);
    if (idx === -1) return;
    const priorUser = [...convo.messages.slice(0, idx)].reverse().find(m => m.role === 'user');
    if (!priorUser) return;

    showThinking();
    const personality = document.getElementById('personality-picker').value;
    const reply = await AI.reply({ message: priorUser.content, personality, history: convo.messages.slice(0, idx) });
    hideThinking();

    convo.messages[idx] = { id: Utils.uid(), role: 'bot', content: reply, ts: Date.now() };
    AppState.persistConversations();
    renderMessages();
  }

  function autoGrow(el){
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 140) + 'px';
  }

  function bind(){
    const input = document.getElementById('chat-input');
    document.getElementById('chat-send-btn').addEventListener('click', sendMessage);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
    });
    input.addEventListener('input', () => autoGrow(input));

    document.getElementById('chat-new-btn').addEventListener('click', () => {
      createConvo();
      renderConvoList();
      renderMessages();
    });

    document.getElementById('chat-delete-btn').addEventListener('click', async () => {
      const convo = getActiveConvo();
      if (!convo) return UI.toast('No hay conversación para borrar', 'info');
      const ok = await UI.confirmAction('¿Borrar esta conversación? No se puede deshacer.');
      if (!ok) return;
      deleteConvo(convo.id);
      renderConvoList();
      renderMessages();
      UI.toast('Conversación borrada', 'success');
    });

    document.getElementById('chat-history-toggle').addEventListener('click', () => {
      document.getElementById('chat-history-panel').classList.toggle('is-open-mobile');
      const panel = document.getElementById('chat-history-panel');
      panel.style.display = panel.style.display === 'flex' ? 'none' : 'flex';
    });

    document.getElementById('personality-picker').addEventListener('change', (e) => {
      const convo = getActiveConvo();
      if (convo) { convo.personality = e.target.value; AppState.persistConversations(); }
    });

    document.getElementById('mic-btn').addEventListener('click', () => {
      Voice.listen((transcript) => {
        input.value = (input.value ? input.value + ' ' : '') + transcript;
        autoGrow(input);
      });
    });
  }

  function init(){
    const convo = getActiveConvo();
    if (convo) document.getElementById('personality-picker').value = convo.personality || AppState.settings.personality;
    else document.getElementById('personality-picker').value = AppState.settings.personality;
    renderConvoList();
    renderMessages();
  }

  return { bind, init, renderConvoList, renderMessages };
})();
