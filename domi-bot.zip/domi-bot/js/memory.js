/**
 * memory.js — "Memoria de Domi": el usuario decide explícitamente
 * qué se guarda. Nada se agrega automáticamente desde el chat.
 */
const Memory = (() => {
  let searchTerm = '';

  const catLabels = {
    preferencia: 'Preferencia', proyecto: 'Proyecto', nota: 'Nota',
    configuracion: 'Configuración', dato: 'Dato útil'
  };

  function all(){ return AppState.memories; }

  function search(term){
    const t = term.toLowerCase().trim();
    if (!t) return AppState.memories;
    return AppState.memories.filter(m =>
      m.title.toLowerCase().includes(t) || m.content.toLowerCase().includes(t) || catLabels[m.category]?.toLowerCase().includes(t)
    );
  }

  function add(title, category, content){
    if (AppState.memories.length >= DOMI_CONFIG.MAX_MEMORY_ITEMS) {
      UI.toast('Llegaste al límite de memorias guardadas', 'error');
      return null;
    }
    const item = { id: Utils.uid(), title, category, content, createdAt: Date.now() };
    AppState.memories.unshift(item);
    AppState.persistMemories();
    AppState.logActivity(`Guardó una memoria: "${title}"`);
    return item;
  }

  function update(id, patch){
    const item = AppState.memories.find(m => m.id === id);
    if (!item) return;
    Object.assign(item, patch);
    AppState.persistMemories();
  }

  function remove(id){
    AppState.memories = AppState.memories.filter(m => m.id !== id);
    AppState.persistMemories();
  }

  function render(){
    const list = document.getElementById('memory-list');
    const items = search(searchTerm);
    if (!items.length){
      list.innerHTML = `<li class="empty-state">
        <span class="empty-ico">◐</span>
        ${searchTerm ? 'No encontramos memorias con esa búsqueda.' : 'Todavía no guardaste ninguna memoria.'}
      </li>`;
      return;
    }
    list.innerHTML = items.map(m => `
      <li class="memory-item" data-id="${m.id}">
        <div class="memory-item-head">
          <div><span class="tag">${catLabels[m.category] || m.category}</span><strong>${Utils.escapeHtml(m.title)}</strong></div>
          <div class="memory-item-actions">
            <button class="icon-btn small" data-act="edit" title="Editar">✎</button>
            <button class="icon-btn small danger" data-act="delete" title="Eliminar">🗑</button>
          </div>
        </div>
        <p>${Utils.escapeHtml(m.content)}</p>
      </li>
    `).join('');

    list.querySelectorAll('.memory-item').forEach(el => {
      const id = el.dataset.id;
      el.querySelector('[data-act="delete"]').addEventListener('click', async () => {
        const ok = await UI.confirmAction('¿Eliminar esta memoria definitivamente?');
        if (!ok) return;
        remove(id);
        render();
        Dashboard.render();
        UI.toast('Memoria eliminada', 'success');
      });
      el.querySelector('[data-act="edit"]').addEventListener('click', () => startEdit(id));
    });
  }

  function startEdit(id){
    const item = AppState.memories.find(m => m.id === id);
    if (!item) return;
    document.getElementById('memory-title').value = item.title;
    document.getElementById('memory-category').value = item.category;
    document.getElementById('memory-content').value = item.content;
    const form = document.getElementById('memory-form');
    form.dataset.editingId = id;
    form.querySelector('button[type="submit"]').textContent = 'Guardar cambios';
    form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function resetForm(){
    const form = document.getElementById('memory-form');
    form.reset();
    delete form.dataset.editingId;
    form.querySelector('button[type="submit"]').textContent = 'Guardar en la memoria';
  }

  function bind(){
    document.getElementById('memory-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const title = document.getElementById('memory-title').value.trim();
      const category = document.getElementById('memory-category').value;
      const content = document.getElementById('memory-content').value.trim();
      if (!title || !content) return;

      const form = e.target;
      if (form.dataset.editingId) {
        update(form.dataset.editingId, { title, category, content });
        UI.toast('Memoria actualizada', 'success');
      } else {
        add(title, category, content);
        UI.toast('Memoria guardada', 'success');
      }
      resetForm();
      render();
      Dashboard.render();
    });

    document.getElementById('memory-search').addEventListener('input', Utils.debounce((e) => {
      searchTerm = e.target.value;
      render();
    }, 150));
  }

  return { all, search, add, remove, render, bind };
})();
