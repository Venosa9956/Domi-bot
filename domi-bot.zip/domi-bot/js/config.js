/**
 * config.js
 * Configuración estática de la aplicación.
 * IMPORTANTE: nunca coloques claves API reales en este archivo.
 * La conexión a un motor de IA real se hace contra un backend propio
 * (ver /api/README.md); este frontend solo conoce una URL configurable.
 */
const DOMI_CONFIG = {
  APP_NAME: 'DOMI BOT',
  VERSION: '1.0.0',
  STORAGE_PREFIX: 'domibot::',
  DEFAULT_BOT_NAME: 'Domi Bot',
  DEFAULT_USER_NAME: 'Invitado',
  BOOT_MIN_MS: 1200,
  MAX_MEMORY_ITEMS: 300,
  MAX_NOTES: 500,
  MAX_TASKS: 500,
  TOAST_TTL: 3800,
  // El motor de respuestas local (sin backend) es una demo funcional,
  // no un modelo de lenguaje real.
  PERSONALITIES: {
    normal:      { label: 'Normal',      tone: 'cercano y equilibrado' },
    estudiante:  { label: 'Estudiante',  tone: 'didáctico, con ejemplos simples' },
    tecnico:     { label: 'Técnico',     tone: 'preciso, directo, con detalle técnico' },
    creativo:    { label: 'Creativo',    tone: 'ocurrente, con metáforas e ideas' },
    conciso:     { label: 'Conciso',     tone: 'breve, al grano, sin rodeos' }
  }
};
