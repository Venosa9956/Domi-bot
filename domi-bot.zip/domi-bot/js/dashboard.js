/**
 * dashboard.js — panel principal, saludo dinámico y contadores.
 */
const Dashboard = (() => {
  const quotes = [
    'Todos los sistemas operativos con normalidad.',
    'Listo para lo que necesites hoy.',
    'Memoria y tareas sincronizadas.',
    'Un buen día para tachar pendientes.',
    'A tu disposición, como siempre.'
  ];

  function render(){
    const name = AppState.settings.username || DOMI_CONFIG.DEFAULT_USER_NAME;
    document.getElementById('dash-greeting').textContent = `${Utils.greetingByHour()},`;
    document.getElementById('dash-username').textContent = name;
    document.getElementById('dash-quote').textContent = quotes[new Date().getDate() % quotes.length];

    const pending = AppState.tasks.filter(t => !t.done).length;
    document.getElementById('dash-tasks-count').textContent = `${pending} pendiente${pending === 1 ? '' : 's'}`;
    document.getElementById('dash-notes-count').textContent = `${AppState.notes.length} guardada${AppState.notes.length === 1 ? '' : 's'}`;
    document.getElementById('dash-memory-count').textContent = `${AppState.memories.length} registro${AppState.memories.length === 1 ? '' : 's'}`;

    renderActivity();
  }

  function renderActivity(){
    const list = document.getElementById('dash-activity-list');
    if (!AppState.activity.length){
      list.innerHTML = `<li class="empty-state">Sin actividad reciente todavía.</li>`;
      return;
    }
    list.innerHTML = AppState.activity.slice(0, 8).map(item => `
      <li style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--panel-border);font-size:0.85rem;">
        <span>${Utils.escapeHtml(item.text)}</span>
        <span style="color:var(--text-2);font-size:0.75rem;white-space:nowrap;">${Utils.formatRelative(item.ts)}</span>
      </li>
    `).join('');
  }

  function bind(){
    document.getElementById('dash-activity-clear').addEventListener('click', async () => {
      const ok = await UI.confirmAction('¿Borrar el historial de actividad reciente?');
      if (!ok) return;
      AppState.activity = [];
      AppState.persistActivity();
      renderActivity();
      UI.toast('Actividad borrada', 'success');
    });
  }

  return { render, bind };
})();
