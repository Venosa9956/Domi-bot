/**
 * app.js — bootstrap de DOMI BOT.
 */
(function boot(){
  const bootStatus = document.getElementById('boot-status');
  const messages = [
    'Inicializando núcleo…',
    'Cargando memoria local…',
    'Preparando módulos…',
    'Sincronizando interfaz…'
  ];
  let i = 0;
  const bootMsgTimer = setInterval(() => {
    i = (i + 1) % messages.length;
    if (bootStatus) bootStatus.textContent = messages[i];
  }, 380);

  function init(){
    if (!Storage.isAvailable()) {
      console.warn('localStorage no disponible: los datos no persistirán entre sesiones.');
    }

    UI.applyTheme();
    UI.bindNav();
    UI.startClock();

    Dashboard.render();
    Dashboard.bind();

    Memory.render();
    Memory.bind();

    Chat.init();
    Chat.bind();

    Tasks.render();
    Tasks.bind();

    Notes.init();
    Notes.bind();

    Tools.init();

    Settings.loadIntoForm();
    Settings.bind();

    Voice.checkSupport();
    Voice.populateVoiceOptions();

    document.getElementById('dash-sys-status').textContent = '● Estado: Operativo';

    finishBoot();
  }

  function finishBoot(){
    clearInterval(bootMsgTimer);
    const boot = document.getElementById('boot-screen');
    const app = document.getElementById('app');
    setTimeout(() => {
      boot.classList.add('is-leaving');
      app.classList.remove('hidden');
      setTimeout(() => boot.remove(), 550);
    }, DOMI_CONFIG.BOOT_MIN_MS);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
