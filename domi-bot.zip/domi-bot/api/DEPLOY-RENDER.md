# Desplegar el backend de DOMI BOT en Render (gratis, sin tarjeta)

Estos pasos asumen que ya tenés una cuenta en Render. Todo el proceso se
hace en el navegador, sin necesidad de tu PC de casa.

## 1. Subí la carpeta `api/` a un repositorio de GitHub

Render despliega desde un repo Git. Si no tenés uno para esto:

1. Entrá a [github.com/new](https://github.com/new) y creá un repo (puede ser
   privado), por ejemplo `domi-bot-backend`.
2. Subí el **contenido de la carpeta `api/`** de este proyecto a ese repo:
   - `server.js`
   - `package.json`
   - `.gitignore`
   - (no subas `.env` — ni siquiera existe todavía, lo vas a crear como
     variable de entorno en Render, nunca en el repo)

   Se puede hacer directo desde la web de GitHub ("Add file → Upload files",
   arrastrando los 3 archivos) sin usar la terminal.

## 2. Creá el Web Service en Render

1. En el dashboard de Render: **New → Web Service**.
2. Conectá tu cuenta de GitHub y elegí el repo `domi-bot-backend`.
3. Configurá:
   - **Name**: `domi-bot-backend` (o el que quieras)
   - **Region**: la más cercana a vos
   - **Branch**: `main`
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free
4. En **Environment Variables**, agregá:
   - `ANTHROPIC_API_KEY` → tu clave de la API de Anthropic (la conseguís en
     [console.anthropic.com](https://console.anthropic.com))
   - `ALLOWED_ORIGIN` → dejalo vacío o en `*` por ahora (restringilo después
     a tu dominio real cuando publiques Domi Bot en algún hosting)
5. Click en **Create Web Service**. Render instala dependencias y arranca
   el servidor solo. La primera vez tarda 1-2 minutos.

## 3. Confirmá que responde

Cuando termine el deploy, Render te da una URL tipo:

```
https://domi-bot-backend.onrender.com
```

Abrila en el navegador — debería mostrar `{"status":"ok",...}`. Eso confirma
que el servidor está arriba (el endpoint del chat es
`https://domi-bot-backend.onrender.com/api/domi`, que solo responde a POST).

## 4. Conectá Domi Bot a ese backend

En la app (el `index.html` o `domi-bot.html`), andá a
**Configuración → Conexión de IA**:
- **URL del backend de IA**: `https://domi-bot-backend.onrender.com/api/domi`
- Activá **"Usar backend de IA en vez del motor local"**
- Tocá **"Probar conexión"**

Si el servicio estaba dormido (nivel gratis, tras 15 min sin uso), el primer
intento puede tardar 30-50 segundos en responder — es normal, no está roto.

## 5. Listo para probar desde el teléfono

Como el backend ya vive en internet (no en tu PC), podés abrir Domi Bot
desde el teléfono, configurar esa misma URL, y el chat va a responder con
Claude de verdad — sin depender de que tu PC de casa esté prendida.

## Notas de seguridad

- La clave `ANTHROPIC_API_KEY` vive únicamente en las variables de entorno
  de Render — nunca en el código ni en el navegador.
- Una vez que confirmes que todo funciona, considerá cambiar
  `ALLOWED_ORIGIN` de `*` a la URL exacta donde publiques Domi Bot, para que
  solo tu app pueda usar ese backend.
- Si en algún momento sospechás que la clave se filtró, regenerala desde la
  consola de Anthropic y actualizá la variable de entorno en Render.
