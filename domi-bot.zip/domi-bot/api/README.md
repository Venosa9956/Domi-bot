# Conectar una IA real a DOMI BOT

Por defecto, DOMI BOT funciona con un **motor de respuestas local** (reglas +
variación), pensado para que la app entera funcione sin necesidad de backend
ni claves. Es una demo funcional, no un modelo de lenguaje real.

Para conectar un modelo de IA real (Claude, GPT, etc.), seguí estos pasos.
**Nunca pongas una clave de API dentro del código del navegador** — cualquiera
que abra las herramientas de desarrollo podría robarla.

## Opción rápida: desplegar en Render (sin PC propia, sin tarjeta)

Si querés probar Domi Bot desde el teléfono sin depender de tu computadora,
seguí [`DEPLOY-RENDER.md`](DEPLOY-RENDER.md) — despliega `server.js` en la
nube en unos minutos, usando el nivel gratuito de Render.

## Opción local: correr el backend en tu propia PC

Usá `server.js` (ya incluye `package.json`):

```bash
cd api
npm install
```

Creá un archivo `.env` en la misma carpeta (ya está en `.gitignore`, no se sube a git):

```
ANTHROPIC_API_KEY=tu_clave_aqui
PORT=3000
```

Iniciá el servidor:

```bash
npm start
```

Tu backend queda escuchando en `http://localhost:3000/api/domi`.

## 2. Configurá DOMI BOT

En la app, andá a **Configuración → Conexión de IA**:
- **URL del backend de IA**: `http://localhost:3000/api/domi` (o la URL pública
  donde despliegues tu backend).
- Activá **"Usar backend de IA en vez del motor local"**.
- Tocá **"Probar conexión"** para confirmar que responde correctamente.

## 3. Contrato de la API

El frontend envía:

```json
POST /api/domi
{
  "message": "texto del usuario",
  "personality": "normal | estudiante | tecnico | creativo | conciso",
  "history": [{ "role": "user|bot", "content": "..." }]
}
```

Y espera como respuesta:

```json
{ "reply": "texto de la respuesta" }
```

Podés adaptar `server.js` a cualquier proveedor de IA (OpenAI, Gemini, un
modelo propio, etc.) siempre que respetes ese contrato de entrada/salida.

## 4. Producción

- Desplegá el backend en un servidor propio (Render, Railway, Fly.io, un VPS,
  etc.), nunca en el mismo bundle que se sirve al navegador.
- Configurá CORS para aceptar solo el dominio donde vive tu DOMI BOT.
- Considerá agregar rate limiting en el backend para evitar abuso de tu clave.
- Si necesitás autenticación de usuarios, agregala en el backend (por ejemplo
  validando un token en cada request), nunca confiando en el frontend.
