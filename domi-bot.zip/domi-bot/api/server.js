/**
 * server.js
 * Backend de DOMI BOT (Node.js + Express) para conectar la app a una
 * IA real (Anthropic) SIN exponer la clave en el navegador.
 * Pensado para desplegarse en Render (ver /api/DEPLOY-RENDER.md).
 *
 * El contrato que espera el frontend:
 *   POST { message: string, personality: string, history: [{role,content}] }
 *   → 200 { reply: string }
 */
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();

// CORS: en producción, restringí ALLOWED_ORIGIN a tu dominio real
// (por ejemplo la URL donde subiste domi-bot.html/index.html).
// Dejalo en "*" mientras probás desde el teléfono con el archivo local.
const allowedOrigin = process.env.ALLOWED_ORIGIN || '*';
app.use(cors({ origin: allowedOrigin }));
app.use(express.json());

app.get('/', (req, res) => res.json({ status: 'ok', service: 'domi-bot-backend' }));

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const PERSONALITY_PROMPTS = {
  normal: 'Sos Domi Bot, un asistente personal cercano, amigable y equilibrado.',
  estudiante: 'Sos Domi Bot. Explicás todo de forma didáctica, simple y con ejemplos, como para alguien que está aprendiendo.',
  tecnico: 'Sos Domi Bot. Respondés de forma precisa, técnica y directa, con el nivel de detalle de un ingeniero.',
  creativo: 'Sos Domi Bot. Respondés con ideas originales, metáforas y un tono ocurrente.',
  conciso: 'Sos Domi Bot. Respondés siempre lo más breve posible, sin rodeos.'
};

app.post('/api/domi', async (req, res) => {
  try {
    const { message, personality = 'normal', history = [] } = req.body || {};
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Falta el campo "message".' });
    }

    const systemPrompt = PERSONALITY_PROMPTS[personality] || PERSONALITY_PROMPTS.normal;

    const messages = [
      ...history
        .filter(m => m && typeof m.content === 'string')
        .slice(-10)
        .map(m => ({ role: m.role === 'bot' ? 'assistant' : 'user', content: m.content })),
      { role: 'user', content: message }
    ];

    const completion = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 600,
      system: systemPrompt,
      messages
    });

    const reply = completion.content
      .filter(block => block.type === 'text')
      .map(block => block.text)
      .join('\n');

    res.json({ reply: reply || 'No pude generar una respuesta esta vez.' });
  } catch (err) {
    console.error('[Domi backend] error:', err);
    res.status(500).json({ error: 'Error interno del backend de IA.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Domi Bot backend escuchando en el puerto ${PORT}`));
